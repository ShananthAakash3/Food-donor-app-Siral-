package com.siral.food_application.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xFF6200EE)
val Purple700 = Color(0xFFABFAEB)
val Teal200 = Color(0xFF03DAC5)

val BlueHue = Color(0xFFE7EEF0)
val PlaceholderGray = Color(0xFF94A5AB)