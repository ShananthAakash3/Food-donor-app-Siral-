package com.siral.food_application.BOs

data class ClientDetails(
    var name :String ="",
    var address: String =""
)
